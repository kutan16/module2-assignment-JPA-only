import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class MainClass {

	public static void main(String[] args) {
		EntityManagerFactory factory = Persistence.createEntityManagerFactory("JPA-PU");
		EntityManager em = factory.createEntityManager();
		Author author = new Author("Nilotpal",
				new Book("book 1", 300.0));
		Author author2 = new Author("Nilotpal",
				new Book("book 2", 400.0));
		Author author3 = new Author("Kutan",
				new Book("book 3", 200.0));
		em.persist(author);
		em.persist(author2);
		em.persist(author3);
		
		
	}

}
