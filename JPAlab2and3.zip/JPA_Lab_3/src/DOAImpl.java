import java.util.List;

public class DOAImpl implements DOA{

	@Override
	public Book save(Book book) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Author findBook(int authorId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Book findAuthor(int bookISBN) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Book> findInRange() {
		// TODO Auto-generated method stub
		return null;
	}

}
