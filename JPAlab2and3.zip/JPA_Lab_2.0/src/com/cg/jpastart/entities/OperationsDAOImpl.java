package com.cg.jpastart.entities;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class OperationsDAOImpl implements OperationsDAO{
	private EntityManagerFactory entityManagerFactory=Persistence.createEntityManagerFactory("JPA-PU");
	@Override
      public void save() {
        EntityManager entityManager=entityManagerFactory.createEntityManager();
        entityManager.getTransaction().begin();
        
        Author author = new Author("Nilotpal", "Lock","Majumdar",7003399);
        
		entityManager.persist(author);
        entityManager.getTransaction().commit();
        entityManager.close();
    }
	@Override
      public void findOne() {  
		EntityManager entityManager=entityManagerFactory.createEntityManager();
	        entityManager.getTransaction().begin();
	        Author author = entityManager.find(Author.class, 1);
	        System.out.println("author id :: " + author.getAuthorId());
	        System.out.println("author firstname :: " + author.getFirstName());
	        System.out.println("author middlename :: " + author.getMiddleName());
	        System.out.println("author lastname :: " + author.getLastName());
	        System.out.println("author phoneno :: " + author.getPhoneNo());
	        entityManager.getTransaction().commit();
	        entityManager.close();
    }
	@Override
	public void update() {
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		entityManager.getTransaction().begin();

		Author author = entityManager.find(Author.class, 1);
        System.out.println("author id :: " + author.getAuthorId());
        System.out.println("author firstname :: " + author.getFirstName());
        System.out.println("author middlename :: " + author.getMiddleName());
        System.out.println("author lastname :: " + author.getLastName());
        System.out.println("author phoneno :: " + author.getPhoneNo());
        author.setFirstName("Kutan");
        author.setLastName("Rex");
        entityManager.getTransaction().commit();
        entityManager.close();
	}
	@Override
	public void remove() {
    	EntityManager entityManager = entityManagerFactory.createEntityManager();
    	entityManager.getTransaction().begin();

    	Author author = entityManager.find(Author.class, 1);
        System.out.println("author id :: " + author.getAuthorId());
        System.out.println("author firstname :: " + author.getFirstName());
        System.out.println("author middlename :: " + author.getMiddleName());
        System.out.println("author lastname :: " + author.getLastName());
        System.out.println("author phoneno :: " + author.getPhoneNo());
        entityManager.remove(author);
        entityManager.getTransaction().commit();
        entityManager.close();
    }
}