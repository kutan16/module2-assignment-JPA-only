package com.cg.jpastart.entities;

import java.util.List;

public interface OperationsDAO {

	void save();

	void remove();

	void update();

	void findOne();
}
